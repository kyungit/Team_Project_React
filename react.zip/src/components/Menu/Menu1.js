import React, {useState} from 'react'
import Box from '../Common/Box'
import Row from "../Common/Row";
import Menu2 from './Menu2';
import Menu3 from './Menu3';
import Menu4 from './Menu4';
import Column from "../Common/Column";


export default function Menu1() {

    const [activeMenu, setActiveMenu] = useState(null);

    const handleMenuClick = (menuNumber) => {
        setActiveMenu(menuNumber);
    }
    // 각 Row의 hover 상태를 관리하기 위한 state
    const [hoverIndex, setHoverIndex] = useState(null);


    // 인라인 스타일 객체 정의
    const rowStyle = (index) => ({
        backgroundColor: hoverIndex === index ? '#ececec' : 'transparent', // 마우스 오버시 색상
        cursor : 'pointer'
    });

    return (

        <div className="col-start-1 col-end-4 w-full h-auto pt-16">
            <Box>
                {['방문 내역', '예약 내역', '내 정보 관리','내가 쓴  리뷰'].map((text, index) => (
                    <div
                        key={index}
                        onMouseEnter={() => setHoverIndex(index)} // 마우스 오버 시작
                        onMouseLeave={() => setHoverIndex(null)} // 마우스 오버 끝
                        style={rowStyle(index)} // 인라인 스타일 적용
                        onClick={() => handleMenuClick(index + 1)}
                    >
                        <Row>{text}</Row>

               {/* <div onClick={() => handleMenuClick(2)} style={rowStyle}>
                    <Row>내 정보 관리</Row>
                </div>
                <div onClick={() => handleMenuClick(3)} style={rowStyle}>
                    <Row>예약 내역</Row>
                </div>
                <div onClick={() => handleMenuClick(4)} style={rowStyle}>
                    <Row>방문 내역</Row>*/}
                </div>

                    ))}
            </Box>
            {activeMenu === 1 && <Menu2/>}
            {activeMenu === 2 && <Menu3/>}
            {activeMenu === 3 && <Menu4/>}


        </div>
    )
}
