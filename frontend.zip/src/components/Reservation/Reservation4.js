import React from 'react'
import Column from '../Common/Column'
import Row from '../Common/Row'
import Box from '../Common/Box'

export default function Reservation4() {
    return (
        <div className="col-start-8 col-end-11 h-auto pt-8">

        </div>
    )
}
