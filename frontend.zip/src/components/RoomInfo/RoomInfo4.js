import React from 'react'

export default function RoomInfo4() {
    return (
        <div className="w-full h-40 pt-16 pl-16">
            <div>Reservation4</div>
        </div>
    )
}
