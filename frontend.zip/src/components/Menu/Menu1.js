import React from 'react'

export default function Menu1() {
    return (
        <div className="w-full h-40 pt-16 pl-16">
            <div>Menu1</div>
        </div>
    )
}
