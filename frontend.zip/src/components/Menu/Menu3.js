import React from 'react'

export default function Menu3() {
    return (
        <div className="w-full h-40 pt-16 pl-16">
            <div>Menu3</div>
        </div>
    )
}
