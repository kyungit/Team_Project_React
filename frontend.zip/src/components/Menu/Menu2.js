import React from 'react'

export default function Menu2() {
    return (
        <div className="w-full h-40 pt-16 pl-16">
            <div>Menu2</div>
        </div>
    )
}
