import React from 'react'

export default function Menu4() {
    return (
        <div className="w-full h-40 pt-16 pl-16">
            <div>Menu4</div>
        </div>
    )
}
