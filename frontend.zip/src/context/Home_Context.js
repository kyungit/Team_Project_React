import { createContext } from 'react'

const HomeContext = createContext()

export default HomeContext
