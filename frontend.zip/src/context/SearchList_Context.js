import { createContext } from 'react'

const SearchListContext = createContext()

export default SearchListContext
