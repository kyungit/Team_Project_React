import { createContext } from 'react'

const RoomInfoContext = createContext()

export default RoomInfoContext
